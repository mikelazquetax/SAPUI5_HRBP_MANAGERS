function initModel() {
	var sUrl = "/RenfeHanaDestination/com/renfe/renfe_lms/loading_process/services/renfe_lms_loading_process.xsodata/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}