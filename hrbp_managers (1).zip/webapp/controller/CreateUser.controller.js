sap.ui.define([
	'sap/base/util/deepExtend',
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History",
	"sap/ui/core/UIComponent",
	'sap/ui/core/BusyIndicator',
], function (deepExtend, Controller, MessageBox, Fragment, Filter, FilterOperator, History, UIComponent, BusyIndicator) {
 
	"use strict";
	var _arrayUsers = [];
	var i;
	return Controller.extend("renfe_lms.hrbp_managers.controller.CreateUser", {
		onInit: function () {

		},

		onCreate: function () {
			var that = this

			var domId = this.getView().byId('dominio').getValue().split(" ")
			var newRecord = {
				"USERID": this.getView().byId('Idnew').getValue(),
				"DOMINIO": domId[0],
				"LAST_DATE": (new Date()).toISOString().split('T')[0]
			};
			var path = '/ZsupervisoresHRBPSet';

			this.getView().getModel().create(path, newRecord, {

				success: function () {

					that.updateHanaDDBB(newRecord.DOMINIO).then(function (apto) { //si se saca satisfactoriamente la info de La TMP_EMPLEADOS, ejecutamos esta funcion con apto = true
							var pathx = '/ZempleadosHRBPSet'
							var userRecord = {
								"USERID": "",
								"FIRSTNAME": "",
								"LASTNAME": "",
								"DOMINIO": "",
								"SUPERID": "",
								"LAST_DATE": ""
							}
							that.i = 0
							that._arrayUsers.forEach((usuario) => {

								userRecord = {
									"USERID": usuario.USER_ID,
									"FIRSTNAME": usuario.APELLIDO_1,
									"LASTNAME": usuario.APELLIDO_2,
									"DOMINIO": usuario.ID_DOMINIO,
									"SUPERID": newRecord.USERID,
									"LAST_DATE": (new Date()).toISOString().split('T')[0]
								}

								if (usuario.APELLIDO_2 == null)
									userRecord.LASTNAME = '-'

								that.getView().getModel().create(pathx, userRecord, {

									success: function () {
										console.log('ok')
										that.i = that.i + 1 
										if(that._arrayUsers.length == that.i){
											
											MessageBox.success('Tabla EMPLEADOS_HRBP actualizada');
										}else{
										
										} 

									},
									error: function (oError) {
										console.log('not ok')
									}

								})

							})

						})
							MessageBox.success('Pre-inscriptor dado de alta con Éxito');
					

				},
				error: function () {
					MessageBox.error('Pre-inscriptor NO Autorizado');
				},

			})

		},
		onValueHelpRequest: function (oEvent) {

			var oView = this.getView();
			var that = this
			var resultado
			this.dominios().then(function (apto) {
				resultado = apto
				if (!that._pValueHelpDialog) {
					that._pValueHelpDialog = Fragment.load({
						id: oView.getId(),
						name: "renfe_lms.hrbp_managers.fragment.ValueHelpDialog",
						controller: that
					}).then(function (oValueHelpDialog, apto) {
						oView.addDependent(oValueHelpDialog);
						return oValueHelpDialog;
					});
				}
				that._pValueHelpDialog.then(function (oValueHelpDialog, apto) {
					that._configValueHelpDialog();
					oValueHelpDialog.open();
				}.bind(that));
			})

		},

		_configValueHelpDialog: function () {
/*			var sInputValue = this.getView().byId("dominio").getValue();

			var oModel = this.getView().getModel('jsonDOM');
			var aProducts = oModel.getData();

			aProducts.forEach(function (oProduct) {
				oProduct.selected = (oProduct.DOMINIO === sInputValue);

			});*/
		//	oModel.setProperty("/DominioSet", aProducts);
		},

		dominios: function () {
			return new Promise((resolve, reject) => {
				var that = this
				this.getView().getModel().read('/DominioSet', {

					success: function (oData, response) {
						//ARRAY
						var datosDOM = oData.results;
						//creacion de la carcasa del modelo
						var oModelNew = new sap.ui.model.json.JSONModel();
						//los datos en el modelo
						oModelNew.setData(datosDOM);
						//append del modelo a la vista
						that.getView().setModel(oModelNew, "jsonDOM");
						resolve(true)
					},
					error: function (oError) {
						resolve(false)
					}
				})
			});

		},

		confirm: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem"),
				oInput = this.byId("dominio");

			if (!oSelectedItem) {
				oInput.resetProperty("value");
				return;
			}

			oInput.setValue(oSelectedItem.getDescription() + " " + '(' + oSelectedItem.getTitle() + ')');
		},

		onBack: function (evento) {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = UIComponent.getRouterFor(that);
				oRouter.navTo("hrbp");
			}
		},

		updateHanaDDBB: function (dominio) {
			var those = this
				//llamamos a HANA para obtener los usuarios del dominio
			return new Promise((resolve, reject) => {
				var that = this

				this.getView().getModel().read('/TmpCargaEmpleadosSet', {
					filters: [
						new Filter("ID_DOMINIO", "EQ", dominio)
					],
					success: function (oData, response) {
						var odataResult = oData.results;
						those._arrayUsers = odataResult;
						resolve(true)

					},
					error: function (errorcito) {
						resolve(false)
					}

				})
			})
		},

	});

});