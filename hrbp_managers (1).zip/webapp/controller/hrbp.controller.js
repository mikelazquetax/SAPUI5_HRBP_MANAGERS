sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, MessageBox,Filter,FilterOperator) {
	"use strict";

	return Controller.extend("renfe_lms.hrbp_managers.controller.hrbp", {
		onInit: function () {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("hrbp").attachPatternMatched(this._onRoutePatternMatched, this);

		},

		_onRoutePatternMatched: function (oEvent) {
			if (oEvent.getParameter("name") === "hrbp") {
				this.onDataTable();
			}

		},

		onAfterRendering: function () {
			this.onDataTable();
		},

		onDataTable: function () {

			var that = this;
			this.getView().getModel().read('/ZsupervisoresHRBPSet', {
				success: function (oData, response) {
					//ARRAY
					var datos = oData.results;
					//creacion de la carcasa del modelo
					var oModelNew = new sap.ui.model.json.JSONModel();
					//los datos en el modelo
					oModelNew.setData(datos);
					//append del modelo a la vista
					that.getView().setModel(oModelNew, "jsonHRBP");
				},
				error: function (oError) {

				}
			});

		},

		btonCreate: function (evento) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CreateUser");
		},
		
		onFilter: function(evento){
		var aFilter = [];
		
			var sQuery = this.getView().byId("inputVal").getValue();
			if (sQuery) {
				aFilter.push(new Filter("USERID", FilterOperator.Contains,sQuery));
			}
		
		
		var users	= this.getView().byId('tableHRBP');
		var oBinding = users.getBinding("rows");
		oBinding.filter(aFilter)
		
		
			

		
		}



	});
});