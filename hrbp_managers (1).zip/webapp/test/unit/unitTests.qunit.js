/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"renfe_lms/hrbp_managers/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});