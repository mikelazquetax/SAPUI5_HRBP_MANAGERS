/*global QUnit*/

sap.ui.define([
	"renfe_lms/hrbp_managers/controller/hrbp.controller"
], function (Controller) {
	"use strict";

	QUnit.module("hrbp Controller");

	QUnit.test("I should test the hrbp controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});