sap.ui.define([
	"renfe_lms/hrbp_managers/test/unit/controller/hrbp.controller"
], function () {
	"use strict";
});